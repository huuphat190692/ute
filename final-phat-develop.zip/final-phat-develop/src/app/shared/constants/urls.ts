import { environment } from 'src/environments/environment';

const BASE_URL = environment.production ? '' : 'http://localhost:6000';
