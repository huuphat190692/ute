export interface IUserPayLoad {
    id: string;
    email: string;
    name: string;
    address: string;
    access_token: string;
    isAdmin: boolean;
    expire: string;
}
